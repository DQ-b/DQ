# DemoSans 字体包

包含 Regular 和 Bold 两个字重。

## 文件说明
- `DemoSans-Regular.ttf` - 常规字重 (400)
- `DemoSans-Bold.ttf`    - 粗体字重 (700)
- `index.html`           - 字体预览页面
- `LICENSE.txt`          - 使用许可

## CSS 使用方法
```css
@font-face {
  font-family: 'DemoSans';
  src: url('DemoSans-Regular.ttf') format('truetype');
  font-weight: 400;
}
@font-face {
  font-family: 'DemoSans';
  src: url('DemoSans-Bold.ttf') format('truetype');
  font-weight: 700;
}
```
